import express from "express"
import { signin, signup } from "../controller/authController.js"
import { varifyOTP } from "../controller/otpController.js"
import { validateSigninFields, validateSignupFields } from "../middleware/authMiddleware.js"

const router = express.Router()

router.post("/signup" , validateSignupFields ,  signup)
router.post("/signin" , validateSigninFields ,  signin)
router.post("/otp/verify" , varifyOTP)

export default router;
