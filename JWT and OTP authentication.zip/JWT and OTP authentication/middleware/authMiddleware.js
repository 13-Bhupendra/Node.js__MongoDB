export const validateSignupFields = (req ,res , next)=>{
    const {email , password , name} = req.body;
    if(email && password && name){
        next()
    }else{
        res.status(400).json({status : false , message: "All field must be required !"});
    }   
}

export const validateSigninFields = (req , res ,next)=>{
    const {email , password } = req.body;
    if(email && password){
        next()
    }else{
        res.status(400).json({status : false , message: "All field must be required !"});
    }
}