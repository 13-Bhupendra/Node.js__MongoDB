import express from "express"
import { connectDB } from "./config/db.js"
import Routers from "./routes/authRoute.js"
import dotenv from "dotenv"
dotenv.config()

const app = express()
app.use(express.json())

connectDB()

app.use("/" , Routers);

app.listen(process.env.PORT , ()=>{
    console.log("Server started successfull on the PORT http://localhost:7000");
})