    import { authCollection } from "../models/authModel.js";
    import bcrypt from "bcrypt";
    import { otpSender } from "../services/otpServices.js";

    export const signup = async (req ,res)=>{
        try {
            const {email , name , password} = req.body;
            const hashedPassword = await bcrypt.hash(password , 10);

            const result = await authCollection.create({email , name , password : hashedPassword});
            res.status(201).json({status : true , message: "User registration successfull !" , result});
        } catch (error) {
            res.status(401).json({status : false , message: "Registration failed !" , error});
        }
    }

    export const signin = async(req ,res)=> {
        try {
            const {email , password} = req.body;
            const user = await authCollection.findOne({email});
            if(!user){
                res.status(400).json({status : false , message: "User not registered , signup first !"});    
            }

            const isMatch = await bcrypt.compare(password , user.password)
            if(!isMatch){
                res.status(400).json({status : false , message: "Password is incorrect !"});
            }

            const otpResult  = await otpSender(email);
            if(!otpResult.status){
                return res.status(500).json(otpResult)
            }
        
            res.json({status : true , message : "OTP sent to email "});
        } catch (error) {
            res.status(500).json({status : false , message: "Signin falied !"});  
        }
    }